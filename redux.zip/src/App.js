import React, { Component } from "react";

import Home from "./Components/Home";

class App extends Component {
  render() {
    return (
      <React.Fragment>
        <Home />
      </React.Fragment>
    );
  }
}

export default App;
